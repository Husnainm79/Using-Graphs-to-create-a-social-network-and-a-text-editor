#QUESTION1
class UniqueSocialNetwork:
    def __init__(self):
        self.unique_graph = {}

    def add_member(self, member_id):
        if member_id not in self.unique_graph:
            self.unique_graph[member_id] = []

    def connect_members(self, member_id1, member_id2):
        if member_id1 in self.unique_graph and member_id2 in self.unique_graph:
            if member_id2 not in self.unique_graph[member_id1]:
                self.unique_graph[member_id1].append(member_id2)
            if member_id1 not in self.unique_graph[member_id2]:
                self.unique_graph[member_id2].append(member_id1)

    def remove_member(self, member_id):
        if member_id in self.unique_graph:
            del self.unique_graph[member_id]
            for member in self.unique_graph:
                self.unique_graph[member] = [friend for friend in self.unique_graph[member] if friend != member_id]

    def remove_connection(self, member_id1, member_id2):
        if member_id1 in self.unique_graph and member_id2 in self.unique_graph:
            self.unique_graph[member_id1] = [friend for friend in self.unique_graph[member_id1] if friend != member_id2]
            self.unique_graph[member_id2] = [friend for friend in self.unique_graph[member_id2] if friend != member_id1]

    def get_friends(self, member_id):
        return self.unique_graph.get(member_id, [])

    def dfs_friends(self, member_id, visited=None):
        if visited is None:
            visited = set()
        visited.add(member_id)
        print(member_id)
        for friend in self.unique_graph.get(member_id, []):
            if friend not in visited:
                self.dfs_friends(friend, visited)

    def besties(self, member_id):
        visited = set()
        queue = [member_id]
        visited.add(member_id)

        while queue:
            current_member = queue.pop(0)
            print(current_member)
            for friend in self.unique_graph.get(current_member, []):
                if friend not in visited:
                    queue.append(friend)
                    visited.add(friend)

# Sample Usage
my_unique_network = UniqueSocialNetwork()
my_unique_network.add_member(1)
my_unique_network.add_member(2)
my_unique_network.add_member(3)
my_unique_network.connect_members(1, 2)
my_unique_network.connect_members(2, 3)

print("DFS Friends:")
my_unique_network.dfs_friends(1)

print("\nBesties:")
my_unique_network.besties(1)




#QUESTION2
class SocialNetworkGraph:
    def __init__(self):
        self.graph = {}

    def add_user(self, user_id):
        if user_id not in self.graph:
            self.graph[user_id] = []

    def add_connection(self, user_id1, user_id2):
        if user_id1 in self.graph and user_id2 in self.graph:
            if user_id2 not in self.graph[user_id1]:
                self.graph[user_id1].append(user_id2)
            if user_id1 not in self.graph[user_id2]:
                self.graph[user_id2].append(user_id1)

    def remove_user(self, user_id):
        if user_id in self.graph:
            del self.graph[user_id]
            for user in self.graph:
                self.graph[user] = [friend for friend in self.graph[user] if friend != user_id]

    def remove_connection(self, user_id1, user_id2):
        if user_id1 in self.graph and user_id2 in self.graph:
            self.graph[user_id1] = [friend for friend in self.graph[user_id1] if friend != user_id2]
            self.graph[user_id2] = [friend for friend in self.graph[user_id2] if friend != user_id1]

    def get_friends(self, user_id):
        return self.graph.get(user_id, [])

    def dfs_friends(self, user_id, visited=None):
        if visited is None:
            visited = set()
        visited.add(user_id)
        print(user_id)
        for friend in self.graph.get(user_id, []):
            if friend not in visited:
                self.dfs_friends(friend, visited)

    def besties(self, user_id):
        visited = set()
        queue = [user_id]
        visited.add(user_id)

        while queue:
            current_user = queue.pop(0)
            print(current_user)
            for friend in self.graph.get(current_user, []):
                if friend not in visited:
                    queue.append(friend)
                    visited.add(friend)

# Sample Usage
social_network = SocialNetworkGraph()
social_network.add_user(1)
social_network.add_user(2)
social_network.add_user(3)
social_network.add_connection(1, 2)
social_network.add_connection(2, 3)

print("DFS Friends:")
social_network.dfs_friends(1)

print("\nBFS Friends:")
social_network.besties(1)


class HashMap:
    def __init__(self, capacity=8):
        self.size = 0
        self.capacity = capacity
        self.table = [[] for _ in range(capacity)]

    def hash_function(self, key):
        return hash(key) % self.capacity

    def put(self, key, value):
        index = self.hash_function(key)
        for pair in self.table[index]:
            if pair[0] == key:
                pair[1] = value
                return
        self.table[index].append([key, value])
        self.size += 1

    def get(self, key):
        index = self.hash_function(key)
        for pair in self.table[index]:
            if pair[0] == key:
                return pair[1]
        return None

# Sample Usage
hash_map = HashMap()
hash_map.put("foo", 1)
hash_map.put("bar", 2)
hash_map.put("baz", 3)

print(hash_map.get("foo"))  # Output: 1
print(hash_map.get("bar"))  # Output: 2
print(hash_map.get("qux"))  # Output: None



class SpellChecker:
    def __init__(self, word_list_file):
        self.word_list = HashMap()
        with open(word_list_file, 'r') as file:
            for line in file:
                word = line.strip().lower()
                self.word_list.put(word, 0)

    def check_spelling(self, doc_file):
        with open(doc_file, 'r') as file:
            for line in file:
                words = line.strip().split()
                for word in words:
                    if self.word_list.get(word.lower()) is None:
                        print(f"Misspelled word: {word}")
                        suggestion = self.suggest_spelling(word)
                        print(f"Suggestion: {suggestion}")

    def edit_distance(self, word1, word2):
        m, n = len(word1), len(word2)
        d = [[0] * (n + 1) for _ in range(m + 1)]

        for i in range(m + 1):
            d[i][0] = i
        for j in range(n + 1):
            d[0][j] = j

        for j in range(1, n + 1):
            for i in range(1, m + 1):
                if word1[i - 1] == word2[j - 1]:
                    d[i][j] = d[i - 1][j - 1]
                else:
                    d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + 1)

        return d[m][n]

    def suggest_spelling(self, misspelled_word):
        suggestions = self.word_list.table
        min_distance = float('inf')
        suggestion = None

        for pair in suggestions:
            for word, _ in pair:
                distance = self.edit_distance(misspelled_word, word)
                if distance < min_distance:
                    min_distance = distance
                    suggestion = word

        return suggestion

# Sample Usage
spell_checker = SpellChecker('words.txt')
spell_checker.check_spelling('doc.txt')




